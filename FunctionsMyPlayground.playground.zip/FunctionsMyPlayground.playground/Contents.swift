import UIKit

var str = "Hello, playground"

func addTwoNumbers(){
    let a = 5
    let b = 3
    let c = a + b
    
    print(c)

}

func substractTwoNumbers() {
    let a = 3
    let d = 2
    let e = a - d
    
    print(e)
}

addTwoNumbers()
substractTwoNumbers()

